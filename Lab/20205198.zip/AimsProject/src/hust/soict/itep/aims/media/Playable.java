package hust.soict.itep.aims.media;

public interface Playable {
	public void play();
}
